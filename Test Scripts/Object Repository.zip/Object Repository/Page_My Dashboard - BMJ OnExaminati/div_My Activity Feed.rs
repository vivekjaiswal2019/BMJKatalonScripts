<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_My Activity Feed</name>
   <tag></tag>
   <elementGuidId>12a21fda-7b64-4d23-aa7f-9d138f6d1645</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;activityFeed&quot;)[count(. | //div[@id = 'activityFeed' and @class = 'profile-activity-feed' and (text() = '
                        My Activity Feed
                        
                                
                                
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 33.33%
                                    …5 days ago
                                
                            
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 0%
                                    …over a week ago
                                
                            
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 100%
                                    …over a week ago
                                
                            
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 0%
                                    …over a week ago
                                
                            
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 3 questions and scored 33.33%
                                    …over a week ago
                                
                            
                                
                            
                    ' or . = '
                        My Activity Feed
                        
                                
                                
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 33.33%
                                    …5 days ago
                                
                            
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 0%
                                    …over a week ago
                                
                            
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 100%
                                    …over a week ago
                                
                            
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 0%
                                    …over a week ago
                                
                            
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 3 questions and scored 33.33%
                                    …over a week ago
                                
                            
                                
                            
                    ')]) = count(//div[@id = 'activityFeed' and @class = 'profile-activity-feed' and (text() = '
                        My Activity Feed
                        
                                
                                
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 33.33%
                                    …5 days ago
                                
                            
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 0%
                                    …over a week ago
                                
                            
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 100%
                                    …over a week ago
                                
                            
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 0%
                                    …over a week ago
                                
                            
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 3 questions and scored 33.33%
                                    …over a week ago
                                
                            
                                
                            
                    ' or . = '
                        My Activity Feed
                        
                                
                                
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 33.33%
                                    …5 days ago
                                
                            
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 0%
                                    …over a week ago
                                
                            
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 100%
                                    …over a week ago
                                
                            
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 0%
                                    …over a week ago
                                
                            
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 3 questions and scored 33.33%
                                    …over a week ago
                                
                            
                                
                            
                    ')])]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='activityFeed']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>activityFeed</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>profile-activity-feed</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        My Activity Feed
                        
                                
                                
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 33.33%
                                    …5 days ago
                                
                            
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 0%
                                    …over a week ago
                                
                            
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 100%
                                    …over a week ago
                                
                            
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 0%
                                    …over a week ago
                                
                            
                                
                                    vivek.jaiswal - just completed a Question Session assessment consisting of 3 questions and scored 33.33%
                                    …over a week ago
                                
                            
                                
                            
                    </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;activityFeed&quot;)</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <value>//div[@id='activityFeed']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <value>//form[@id='form1']/div[4]/div/div[5]/div[2]/div/div[4]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Group Learning'])[1]/following::div[9]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//div[2]/div/div[4]</value>
   </webElementXpaths>
</WebElementEntity>
