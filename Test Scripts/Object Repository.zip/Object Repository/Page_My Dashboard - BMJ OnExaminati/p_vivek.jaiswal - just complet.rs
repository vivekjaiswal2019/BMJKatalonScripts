<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_vivek.jaiswal - just complet</name>
   <tag></tag>
   <elementGuidId>5e3e8b63-a28a-450a-99fe-d56033f46b49</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;activityFeed&quot;)/ul[@class=&quot;profile-activity-list&quot;]/li[@class=&quot;activityFeedItem&quot;]/p[1][count(. | //p[(text() = 'vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 33.33%
                                    …5 days ago' or . = 'vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 33.33%
                                    …5 days ago')]) = count(//p[(text() = 'vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 33.33%
                                    …5 days ago' or . = 'vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 33.33%
                                    …5 days ago')])]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='activityFeed']/ul/li/p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>vivek.jaiswal - just completed a Question Session assessment consisting of 1 questions and scored 33.33%
                                    …5 days ago</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;activityFeed&quot;)/ul[@class=&quot;profile-activity-list&quot;]/li[@class=&quot;activityFeedItem&quot;]/p[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <value>//div[@id='activityFeed']/ul/li/p</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='My Activity Feed'])[1]/following::p[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='…over a week ago'])[1]/preceding::p[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//li/p</value>
   </webElementXpaths>
</WebElementEntity>
