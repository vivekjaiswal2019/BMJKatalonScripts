<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Please Select...AllMedi</name>
   <tag></tag>
   <elementGuidId>066e146e-4a46-4b3f-ba11-b9935dd63ffe</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='MainContent_ddlSpec']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;MainContent_ddlSpec&quot;)[count(. | //select[@name = 'ctl00$MainContent$ddlSpec' and @id = 'MainContent_ddlSpec' and @tabindex = '6' and @class = 'form-control' and (text() = '
	Please Select...
	All
	Medicine
	Surgery
	General Practice
	Psychiatry
	Obs &amp; Gynae
	Paediatrics
	Dentistry
	Miscellaneous
	Blog
	Diabetes

' or . = '
	Please Select...
	All
	Medicine
	Surgery
	General Practice
	Psychiatry
	Obs &amp; Gynae
	Paediatrics
	Dentistry
	Miscellaneous
	Blog
	Diabetes

')]) = count(//select[@name = 'ctl00$MainContent$ddlSpec' and @id = 'MainContent_ddlSpec' and @tabindex = '6' and @class = 'form-control' and (text() = '
	Please Select...
	All
	Medicine
	Surgery
	General Practice
	Psychiatry
	Obs &amp; Gynae
	Paediatrics
	Dentistry
	Miscellaneous
	Blog
	Diabetes

' or . = '
	Please Select...
	All
	Medicine
	Surgery
	General Practice
	Psychiatry
	Obs &amp; Gynae
	Paediatrics
	Dentistry
	Miscellaneous
	Blog
	Diabetes

')])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>ctl00$MainContent$ddlSpec</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>MainContent_ddlSpec</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>6</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	Please Select...
	All
	Medicine
	Surgery
	General Practice
	Psychiatry
	Obs &amp; Gynae
	Paediatrics
	Dentistry
	Miscellaneous
	Blog
	Diabetes

</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;MainContent_ddlSpec&quot;)</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <value>//select[@id='MainContent_ddlSpec']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <value>//form[@id='form1']/div[4]/div/div[2]/div[2]/div/div[4]/select[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Default news speciality:'])[1]/following::select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Active revision course:'])[1]/following::select[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Email me my scores weekly.'])[1]/preceding::select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Personal Details'])[1]/preceding::select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//select[2]</value>
   </webElementXpaths>
</WebElementEntity>
