<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Please selectCareer Gra</name>
   <tag></tag>
   <elementGuidId>da9061b5-0df8-41db-97db-1954a9061eef</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;MainContent_ddlGrade&quot;)[count(. | //select[@name = 'ctl00$MainContent$ddlGrade' and @tabindex = '7' and @class = 'form-control' and (text() = '
	Please select
	Career Grade
	Clinical Assistant
	Consultant
	Dental Nurse
	General Practitioner
	GP Registrar
	House Officer / FP1
	Medical Student
	Other
	Senior House Officer / FP2
	Specialist Registrar

' or . = '
	Please select
	Career Grade
	Clinical Assistant
	Consultant
	Dental Nurse
	General Practitioner
	GP Registrar
	House Officer / FP1
	Medical Student
	Other
	Senior House Officer / FP2
	Specialist Registrar

')]) = count(//select[@name = 'ctl00$MainContent$ddlGrade' and @tabindex = '7' and @class = 'form-control' and (text() = '
	Please select
	Career Grade
	Clinical Assistant
	Consultant
	Dental Nurse
	General Practitioner
	GP Registrar
	House Officer / FP1
	Medical Student
	Other
	Senior House Officer / FP2
	Specialist Registrar

' or . = '
	Please select
	Career Grade
	Clinical Assistant
	Consultant
	Dental Nurse
	General Practitioner
	GP Registrar
	House Officer / FP1
	Medical Student
	Other
	Senior House Officer / FP2
	Specialist Registrar

')])]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='MainContent_ddlGrade']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>ctl00$MainContent$ddlGrade</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>MainContent_ddlGrade</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>7</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	Please select
	Career Grade
	Clinical Assistant
	Consultant
	Dental Nurse
	General Practitioner
	GP Registrar
	House Officer / FP1
	Medical Student
	Other
	Senior House Officer / FP2
	Specialist Registrar

</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;MainContent_ddlGrade&quot;)</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <value>//select[@id='MainContent_ddlGrade']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <value>//form[@id='form1']/div[4]/div/div[2]/div[3]/div/div/div[6]/select</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Grade:'])[1]/following::select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Certification body number:'])[1]/following::select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Communication preferences'])[1]/preceding::select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Error: Invalid email address, or email address entered already exists'])[1]/preceding::select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//div[6]/select</value>
   </webElementXpaths>
</WebElementEntity>
