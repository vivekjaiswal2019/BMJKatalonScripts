<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i_Loading..._fa fa-twitter-squ</name>
   <tag></tag>
   <elementGuidId>b1e87cd2-072a-46ed-a40d-e7ff9443fb5a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;form1&quot;)/div[@class=&quot;page-container&quot;]/header[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;hidden-xs col-sm-6  col-md-6&quot;]/ul[@class=&quot;socMediaIcons&quot;]/li[2]/a[1]/i[@class=&quot;fa fa-twitter-square&quot;][count(. | //i[@class = 'fa fa-twitter-square']) = count(//i[@class = 'fa fa-twitter-square'])]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='form1']/div[4]/header/div/div[2]/ul/li[2]/a/i</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fa fa-twitter-square</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;form1&quot;)/div[@class=&quot;page-container&quot;]/header[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;hidden-xs col-sm-6  col-md-6&quot;]/ul[@class=&quot;socMediaIcons&quot;]/li[2]/a[1]/i[@class=&quot;fa fa-twitter-square&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <value>//form[@id='form1']/div[4]/header/div/div[2]/ul/li[2]/a/i</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Loading...'])[1]/following::i[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign In'])[1]/preceding::i[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Toggle navigation'])[1]/preceding::i[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//li[2]/a/i</value>
   </webElementXpaths>
</WebElementEntity>
