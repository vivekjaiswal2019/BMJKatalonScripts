<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>img_Sign Out_Facebooklogo img-</name>
   <tag></tag>
   <elementGuidId>02659a5b-20f4-4f5b-b586-be96658e938e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;form1&quot;)/div[@class=&quot;page-container&quot;]/header[@class=&quot;container-fluid header hidden-xs&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;hidden-xs col-sm-6  col-md-6&quot;]/div[1]/div[2]/span[@class=&quot;socMediaIcons&quot;]/a[2]/img[@class=&quot;Facebooklogo img-fluid&quot;][count(. | //img[@src = 'https://media.onexamination.com/Images/www/Facebook_White.png' and @class = 'Facebooklogo img-fluid']) = count(//img[@src = 'https://media.onexamination.com/Images/www/Facebook_White.png' and @class = 'Facebooklogo img-fluid'])]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='form1']/div[4]/header/div/div/div[2]/div/div[2]/span[2]/a[2]/img</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>img</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>src</name>
      <type>Main</type>
      <value>https://media.onexamination.com/Images/www/Facebook_White.png</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>Facebooklogo img-fluid</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;form1&quot;)/div[@class=&quot;page-container&quot;]/header[@class=&quot;container-fluid header hidden-xs&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;hidden-xs col-sm-6  col-md-6&quot;]/div[1]/div[2]/span[@class=&quot;socMediaIcons&quot;]/a[2]/img[@class=&quot;Facebooklogo img-fluid&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <value>//form[@id='form1']/div[4]/header/div/div/div[2]/div/div[2]/span[2]/a[2]/img</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Out'])[1]/following::img[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='My Profile'])[1]/following::img[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Toggle navigation'])[1]/preceding::img[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home'])[1]/preceding::img[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:img</name>
      <value>//img[contains(@src,'https://media.onexamination.com/Images/www/Facebook_White.png')]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//a[2]/img</value>
   </webElementXpaths>
</WebElementEntity>
