<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Edit exams</name>
   <tag></tag>
   <elementGuidId>61674641-33ee-4b6a-91a2-fa9b03442275</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;MainContent_gvUsers&quot;)/tbody[1]/tr[@class=&quot;row&quot;]/td[6]/a[1][count(. | //a[@href = concat('javascript:__doPostBack(' , &quot;'&quot; , 'ctl00$MainContent$gvUsers' , &quot;'&quot; , ',' , &quot;'&quot; , 'EditExams$0' , &quot;'&quot; , ')') and (text() = 'Edit exams' or . = 'Edit exams')]) = count(//a[@href = concat('javascript:__doPostBack(' , &quot;'&quot; , 'ctl00$MainContent$gvUsers' , &quot;'&quot; , ',' , &quot;'&quot; , 'EditExams$0' , &quot;'&quot; , ')') and (text() = 'Edit exams' or . = 'Edit exams')])]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//table[@id='MainContent_gvUsers']/tbody/tr[2]/td[6]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>javascript:__doPostBack('ctl00$MainContent$gvUsers','EditExams$0')</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Edit exams</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;MainContent_gvUsers&quot;)/tbody[1]/tr[@class=&quot;row&quot;]/td[6]/a[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <value>//table[@id='MainContent_gvUsers']/tbody/tr[2]/td[6]/a</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <value>//a[contains(text(),'Edit exams')]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Suggestions &amp; notes'])[1]/following::a[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Edit roles'])[1]/following::a[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Edit video tutorials'])[1]/preceding::a[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Edit tests'])[1]/preceding::a[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <value>//a[contains(@href, &quot;javascript:__doPostBack('ctl00$MainContent$gvUsers','EditExams$0')&quot;)]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//td[6]/a</value>
   </webElementXpaths>
</WebElementEntity>
