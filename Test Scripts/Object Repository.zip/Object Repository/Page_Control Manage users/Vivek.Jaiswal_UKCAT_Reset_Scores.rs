<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Vivek.Jaiswal_UKCAT_Reset_Scores</name>
   <tag></tag>
   <elementGuidId>c4ba23f1-35c7-4926-a304-9b71edd4af39</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//input[@value='Reset Scores'])[63]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;MainContent_gvUserExam&quot;)/tbody[1]/tr[@class=&quot;alternatingRow&quot;]/td[9]/input[1][count(. | //input[@type = 'button' and @value = 'Reset Scores' and @onclick = concat('javascript:__doPostBack(' , &quot;'&quot; , 'ctl00$MainContent$gvUserExam' , &quot;'&quot; , ',' , &quot;'&quot; , 'Reset$7' , &quot;'&quot; , ')')]) = count(//input[@type = 'button' and @value = 'Reset Scores' and @onclick = concat('javascript:__doPostBack(' , &quot;'&quot; , 'ctl00$MainContent$gvUserExam' , &quot;'&quot; , ',' , &quot;'&quot; , 'Reset$7' , &quot;'&quot; , ')')])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>input</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>value</name>
      <type>Main</type>
      <value>Reset Scores</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onclick</name>
      <type>Main</type>
      <value>javascript:__doPostBack('ctl00$MainContent$gvUserExam','Reset$7')</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;MainContent_gvUserExam&quot;)/tbody[1]/tr[@class=&quot;alternatingRow&quot;]/td[9]/input[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <value>(//input[@value='Reset Scores'])[63]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <value>//table[@id='MainContent_gvUserExam']/tbody/tr[64]/td[9]/input</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Edit'])[63]/following::input[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Not country specific'])[63]/following::input[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Alias'])[1]/preceding::input[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Active'])[1]/preceding::input[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//tr[64]/td[9]/input</value>
   </webElementXpaths>
</WebElementEntity>
