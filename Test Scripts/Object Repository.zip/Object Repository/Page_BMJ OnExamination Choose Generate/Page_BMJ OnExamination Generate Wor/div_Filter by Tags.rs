<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Filter by Tags</name>
   <tag></tag>
   <elementGuidId>69b9bb2e-5aa3-4e99-8620-8f9305845bf5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='genTagSelect']/div</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;genTagSelect&quot;)/div[@class=&quot;panel panel-default ws-config-block clearfix&quot;][count(. | //div[@class = 'panel panel-default ws-config-block clearfix' and (text() = '
                
                    Filter by Tags
                    
                        
                            
                            No tags
                        
                        
                            
                            Select tags            
                        
                    
                
                    
                        
                            
                                My Tags
                                tagaTagBRemove
                            
                            
                                Editorial Tags
                                Core Questions
                            
                        
                    
                
            ' or . = '
                
                    Filter by Tags
                    
                        
                            
                            No tags
                        
                        
                            
                            Select tags            
                        
                    
                
                    
                        
                            
                                My Tags
                                tagaTagBRemove
                            
                            
                                Editorial Tags
                                Core Questions
                            
                        
                    
                
            ')]) = count(//div[@class = 'panel panel-default ws-config-block clearfix' and (text() = '
                
                    Filter by Tags
                    
                        
                            
                            No tags
                        
                        
                            
                            Select tags            
                        
                    
                
                    
                        
                            
                                My Tags
                                tagaTagBRemove
                            
                            
                                Editorial Tags
                                Core Questions
                            
                        
                    
                
            ' or . = '
                
                    Filter by Tags
                    
                        
                            
                            No tags
                        
                        
                            
                            Select tags            
                        
                    
                
                    
                        
                            
                                My Tags
                                tagaTagBRemove
                            
                            
                                Editorial Tags
                                Core Questions
                            
                        
                    
                
            ')])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>panel panel-default ws-config-block clearfix</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    Filter by Tags
                    
                        
                            
                            No tags
                        
                        
                            
                            Select tags            
                        
                    
                
                    
                        
                            
                                My Tags
                                tagaTagBRemove
                            
                            
                                Editorial Tags
                                Core Questions
                            
                        
                    
                
            </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;genTagSelect&quot;)/div[@class=&quot;panel panel-default ws-config-block clearfix&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <value>//div[@id='genTagSelect']/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AdaptForMe™'])[1]/following::div[4]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Hard'])[1]/following::div[5]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//div[8]/div/div/div</value>
   </webElementXpaths>
</WebElementEntity>
