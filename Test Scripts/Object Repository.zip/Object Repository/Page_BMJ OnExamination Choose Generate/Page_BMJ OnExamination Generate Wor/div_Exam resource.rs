<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Exam resource</name>
   <tag></tag>
   <elementGuidId>6ea9a547-1613-48ba-bd4e-0f7aa6e174bc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='settingsBox']/div/div/div</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;settingsBox&quot;)/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;form-group settings-box&quot;][count(. | //div[@class = 'form-group settings-box' and (text() = '
                        Exam resource:
                        DRCOGEndocrinology and Diabetes SCEFRCR Part 1FRCS - General SurgeryGastroenterology SCEMedical Student EndocrinologyMedical Student GastroenterologyMRCGPMRCP Part 1MRCP Part 2 WrittenTropical Health Education Trust moduleUKCAT
                    ' or . = '
                        Exam resource:
                        DRCOGEndocrinology and Diabetes SCEFRCR Part 1FRCS - General SurgeryGastroenterology SCEMedical Student EndocrinologyMedical Student GastroenterologyMRCGPMRCP Part 1MRCP Part 2 WrittenTropical Health Education Trust moduleUKCAT
                    ')]) = count(//div[@class = 'form-group settings-box' and (text() = '
                        Exam resource:
                        DRCOGEndocrinology and Diabetes SCEFRCR Part 1FRCS - General SurgeryGastroenterology SCEMedical Student EndocrinologyMedical Student GastroenterologyMRCGPMRCP Part 1MRCP Part 2 WrittenTropical Health Education Trust moduleUKCAT
                    ' or . = '
                        Exam resource:
                        DRCOGEndocrinology and Diabetes SCEFRCR Part 1FRCS - General SurgeryGastroenterology SCEMedical Student EndocrinologyMedical Student GastroenterologyMRCGPMRCP Part 1MRCP Part 2 WrittenTropical Health Education Trust moduleUKCAT
                    ')])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-group settings-box</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        Exam resource:
                        DRCOGEndocrinology and Diabetes SCEFRCR Part 1FRCS - General SurgeryGastroenterology SCEMedical Student EndocrinologyMedical Student GastroenterologyMRCGPMRCP Part 1MRCP Part 2 WrittenTropical Health Education Trust moduleUKCAT
                    </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;settingsBox&quot;)/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;form-group settings-box&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <value>//div[@id='settingsBox']/div/div/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Choose Questions'])[2]/following::div[6]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Current Options Selected'])[1]/preceding::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//div[2]/div[2]/div/div[2]/div/div/div</value>
   </webElementXpaths>
</WebElementEntity>
