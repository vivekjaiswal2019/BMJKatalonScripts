<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Filter by Curriculum</name>
   <tag></tag>
   <elementGuidId>3602eaf0-2788-4a0b-812c-5187a22f6a12</elementGuidId>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>panel-body</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                    Filter by Curriculum
                    
                        
                            
                            All curricula
                        
                        
                            
                            Select curriculum
                        
                    
                    
                        Cancer and palliative care and haematologyCardiorespiratory arrest and shockCardiovascular medicineClinical pharmacology &amp; poisoningDiabetes and endocrine medicineGastroenterology and hepatologyInfectious diseasesMedicine in the elderlyMusculoskeletal systemNeurology and ophthalmologyOtherAllergyClinical geneticsDermatologyPsychiatryPublic health and health promotionRenal medicineRespiratory medicine
                    
                </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;genCatSelect&quot;)/div[@class=&quot;panel panel-default ws-config-block clearfix&quot;]/div[@class=&quot;panel-body&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <value>//div[@id='genCatSelect']/div/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Generate test'])[1]/following::div[12]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='All'])[1]/following::div[13]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//div[5]/div/div/div/div</value>
   </webElementXpaths>
</WebElementEntity>
