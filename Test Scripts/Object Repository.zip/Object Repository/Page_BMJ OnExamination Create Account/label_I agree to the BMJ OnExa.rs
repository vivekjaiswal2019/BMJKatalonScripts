<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_I agree to the BMJ OnExa</name>
   <tag></tag>
   <elementGuidId>f6d40ff3-1808-4778-a2cb-838a26cd4164</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='MainContent_RegistrationPanel']/div/div/div[5]/div/label</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;MainContent_RegistrationPanel&quot;)/div[@class=&quot;panel panel-default grey-block create-account&quot;]/div[@class=&quot;panel-body&quot;]/div[@class=&quot;form-group&quot;]/div[@class=&quot;checkbox&quot;]/label[1][count(. | //label[@for = 'MainContent_chkTermsConditions' and (text() = 'I agree to the BMJ OnExamination terms, conditions and privacy policy.' or . = 'I agree to the BMJ OnExamination terms, conditions and privacy policy.')]) = count(//label[@for = 'MainContent_chkTermsConditions' and (text() = 'I agree to the BMJ OnExamination terms, conditions and privacy policy.' or . = 'I agree to the BMJ OnExamination terms, conditions and privacy policy.')])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>MainContent_chkTermsConditions</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>I agree to the BMJ OnExamination terms, conditions and privacy policy.</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;MainContent_RegistrationPanel&quot;)/div[@class=&quot;panel panel-default grey-block create-account&quot;]/div[@class=&quot;panel-body&quot;]/div[@class=&quot;form-group&quot;]/div[@class=&quot;checkbox&quot;]/label[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <value>//div[@id='MainContent_RegistrationPanel']/div/div/div[5]/div/label</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Communication preferences'])[1]/following::label[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Your new password and confirmed password must match'])[1]/following::label[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download our Mobile App'])[2]/preceding::label[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//div[5]/div/label</value>
   </webElementXpaths>
</WebElementEntity>
