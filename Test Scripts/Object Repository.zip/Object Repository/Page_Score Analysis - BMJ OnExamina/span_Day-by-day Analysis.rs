<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Day-by-day Analysis</name>
   <tag></tag>
   <elementGuidId>60f0815c-e28a-4313-a896-5d3ae79973db</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;bs-example-navbar-collapse-1&quot;)/div[@class=&quot;secondary-navigation&quot;]/div[@class=&quot;container&quot;]/ul[@class=&quot;nav navbar-nav&quot;]/li[3]/a[@class=&quot;navItemInactive&quot;]/span[1][count(. | //span[(text() = 'Day-by-day Analysis' or . = 'Day-by-day Analysis')]) = count(//span[(text() = 'Day-by-day Analysis' or . = 'Day-by-day Analysis')])]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='bs-example-navbar-collapse-1']/div[2]/div/ul/li[3]/a/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Day-by-day Analysis</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;bs-example-navbar-collapse-1&quot;)/div[@class=&quot;secondary-navigation&quot;]/div[@class=&quot;container&quot;]/ul[@class=&quot;nav navbar-nav&quot;]/li[3]/a[@class=&quot;navItemInactive&quot;]/span[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <value>//div[@id='bs-example-navbar-collapse-1']/div[2]/div/ul/li[3]/a/span</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Curricula Overview'])[1]/following::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Score Analysis'])[1]/following::span[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Learning Journal'])[1]/preceding::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Score Analysis - UKCAT'])[1]/preceding::span[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//div[2]/div/ul/li[3]/a/span</value>
   </webElementXpaths>
</WebElementEntity>
